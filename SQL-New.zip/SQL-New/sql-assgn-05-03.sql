
use db1;
CREATE TABLE Artists( ArtistId INT PRIMARY KEY, AName VARCHAR(255) ); 
INSERT INTO Artists(ArtistId, AName) VALUES (1, 'Mogwai'),  (2, 'Nirvana'), (3, 'Mono'),  (4, 'Caspian'), (5, 'Red Sparowes'),  
(6, 'Russian Circles'), (7, 'Saxon Shore'),  (8, '65daysofstatic'), (9, 'Maybeshewill'),  (10, 'Yndi Halda'), 
(11, 'Tristeza'),  (12, 'Maserati'), (13, 'Grails'),  (14, 'Dirty Three'), (15, 'Oh Hiroshima'),  (16, 'EF'); 
SELECT *FROM Artists;

drop table Artists;
drop table Albums;
drop table Tracks;
drop table SimilarArtists;
drop table TrackLists;
CREATE TABLE Albums(AlbumId INT PRIMARY KEY,ArtistId INT,AlbumName VARCHAR(255),FOREIGN KEY (ArtistId) REFERENCES Artists(ArtistId));
INSERT INTO Albums(AlbumId, ArtistId, AlbumName) VALUES 
(1, 1, 'Young Team'),  
(2, 2, 'Nevermind'),  
(3, 3, 'OK Computer'),  
(4, 4, 'Parachutes'), 
 (5, 5, 'Abbey Road'), 
 (6, 6, 'The Colour and the Shape'),
 (7, 7, 'IV'),  
(8, 8, 'The Dark Side of the Moon'), 
 (9, 9, 'AM'),  (10, 10, 'Let It Bleed'),  
(11, 11, 'Is This It'),  
(12, 12, 'American Idiot'),  
(13, 13, 'Morning Glory?'),  
(14, 14, 'Ten'),  
(15, 15, 'The Joshua Tree');

SELECT *FROM Albums;


CREATE TABLE Tracks(TrackId INT PRIMARY KEY,ArtistId INT,TrackName VARCHAR(255),TLength INT,FOREIGN KEY (ArtistId) REFERENCES Artists(ArtistId));
INSERT INTO Tracks(TrackId, ArtistId, TrackName, TLength) VALUES (1,1,'Intro',600000), 
(2,2,'Intro',300000), (3,3,'Track8',500000), (4,1,'Why Track',700000), (5,2,'The Track',800000), (6,4,'Track7',900000), 
(7,5,'Why Track',600000), (8,6,'Intro',500000), (9,7,'The Track',700000), (10,8,'Track5',9000000), (11,9,'Why Track',800000), 
(12,10,'Track1',300000), (13,8,'Track2',100000), (14,9,'The Track',900000), (15,9,'Track3',1000000), (16,10,'Why Track',400000); 
SELECT *FROM Tracks;

CREATE TABLE SimilarArtists(ArtistId INT,SimArtistId INT,Weight INT,FOREIGN KEY (ArtistId) REFERENCES Artists(ArtistId));
INSERT INTO SimilarArtists(Artistid, SimArtistId, Weight)  VALUES (1,1,50), 
(2,2,60), (3,3,70), (4,4,80), (5,1,90), (6,5,50), (7,3,60), 
(8,7,80), (9,4,110), (10,9,30), (11,10,10), (12,11,70), 
(13,12,90), (14,11,120), (15,13,150), (16,14,130); 
SELECT *FROM SimilarArtists;


 
CREATE TABLE TrackLists(AlbumId INT,TrackId INT,TrackNum INT,FOREIGN KEY (AlbumId) REFERENCES Albums(AlbumId),FOREIGN KEY (TrackId) REFERENCES Tracks(TrackId));

INSERT INTO TrackLists(AlbumId, TrackId, Tracknum)  VALUES (1, 15, 1),  
(1, 15, 2),  (1, 3, 3),  (2, 4, 4),  
(2, 5, 5),  (3, 15, 6),  (3, 7, 7),  
(4, 8, 1),  (4, 9, 2),  (5, 10, 5),  
(5, 11, 4),  (6, 12, 3),  (6, 13, 2), 
(7, 14, 6),  (8, 7, 7),  (9, 8, 1),  
(10, 9, 2),  (7, 10, 5),  (6, 11, 4),  (8, 12, 3),  (11, 15, 2);
SELECT *FROM TrackLists;
show tables;

SELECT * FROM Tracks WHERE TLength > 600000;

SELECT DISTINCT a.AName FROM Artists a  
JOIN Albums al ON a.ArtistId = al.ArtistId  
WHERE a.AName = al.AlbumName; 

SELECT ar.AName FROM Albums al  
JOIN Artists ar ON al.ArtistId = ar.ArtistId  
JOIN TrackLists tl ON al.AlbumId = tl.AlbumId  
JOIN Tracks t ON tl.TrackId = t.TrackId  
WHERE tl.TrackNum = 1 and t.TrackName = 'Intro'; 

SELECT s.SimArtistId, a1.AName FROM   SimilarArtists s   JOIN Artists  a ON s.Artistid = a.ArtistId  LEFT JOIN Artists a1 ON s.SimArtistId = a1.ArtistId  
WHERE a.AName = 'Mogwai' OR a.AName = 'Nirvana'  AND s.weight > (SELECT MAX(weight) FROM SimilarArtists WHERE ArtistId = (SELECT ArtistId FROM Artists WHERE AName = 'Nirvana')); 

  
SELECT al.AlbumId, al.AlbumName AS AlbumName, COUNT(tl.trackID) AS Track_Count FROM Albums al  JOIN TrackLists tl ON al.AlbumId = tl.AlbumId  
GROUP BY al.AlbumId, al.AlbumName  HAVING COUNT(tl.TrackId) > 30; 
  
  
  
SELECT al.AName  FROM Artists AS al  WHERE EXISTS (  SELECT *  FROM SimilarArtists S  WHERE S.Artistid = al.ArtistId  and S.weight > 5); 



SELECT al.AlbumId, al.AlbumName AS AlbumName, tl.Tracknum,
CASE   
WHEN tl.Tracknum = 15 THEN t.TrackName ELSE NULL END AS track_name  
FROM Albums AS al  
LEFT JOIN TrackLists AS tl ON al.AlbumId = tl.AlbumId  
LEFT JOIN Tracks AS t ON tl.trackID = t.trackID  
ORDER BY al.AlbumId, tl.Tracknum;  

SELECT a.AName, AVG(t.tlength) AS AvgLength FROM Artists a 
JOIN Tracks t ON t.ArtistId = a.ArtistId 
JOIN Albums al ON a.ArtistId = al.ArtistId  
JOIN TrackLists tl ON tl.AlbumId = al.AlbumId 
GROUP BY a.AName, al.AlbumName 
ORDER BY AvgLength DESC; 


SELECT 
    a.AName AS artist_name,  
    (
        SELECT a2.AName 
        FROM SimilarArtists sa  
        JOIN Artists a2 ON sa.SimArtistId = a2.ArtistId  
        JOIN TrackLists tl2 ON a2.ArtistId = tl2.AlbumId  
        JOIN Tracks t2 ON tl2.TrackId = t2.TrackId  
        WHERE t2.TrackName LIKE 'Why%' AND a2.ArtistId != a.ArtistId  
        ORDER BY sa.Weight ASC, a2.ArtistId ASC 
        LIMIT 1
    ) AS similar_artist_name  
FROM 
    Artists a  
JOIN 
    TrackLists tl ON a.ArtistId = tl.AlbumId  
JOIN 
    Tracks t ON tl.TrackId = t.TrackId  
WHERE 
    t.TrackName LIKE 'The%';


 

 