use db;
CREATE TABLE Models( MId INT PRIMARY KEY, MName VARCHAR(255), MModel VARCHAR(255) );
CREATE TABLE Cars(CarId INT PRIMARY KEY,MId INT,CYear INT,FOREIGN KEY (MId) REFERENCES Models(MId));
CREATE TABLE Buyers( BId INT PRIMARY KEY, BName VARCHAR(50), BCity VARCHAR(255), Age INT ); 
CREATE TABLE Manufacturers( MName VARCHAR(255) PRIMARY KEY, Location VARCHAR(255) ); 
CREATE TABLE Salespersons( SId INT PRIMARY KEY, SName VARCHAR(255), YearsEmployeed INT ); 
CREATE TABLE Transactions(BId INT,CarId INT,SId INT,Amount DECIMAL(10,2),TMonth INT,TDay INT,TYear INT,
    FOREIGN KEY (BId) REFERENCES Buyers(BId),
    FOREIGN KEY (CarId) REFERENCES Cars(CarId),
    FOREIGN KEY (SId) REFERENCES Salespersons(SId)
);
 
 
SELECT *FROM Models;
SELECT *FROM Cars;
SELECT *FROM Buyers;
SELECT *FROM  Manufacturers;
SELECT *FROM Transactions;
SELECT *FROM  Salespersons;




INSERT INTO Models(MId, MName, MModel)  VALUES (1,'Ford','mustang'), (2,'Toyota','innova'), (3,'Honda','city'), (4,'Maruti','esxl'), 
(5,'Tata','punch'); 
INSERT INTO Cars(CarId, MId, CYear) VALUES (1,1,1997), (2,3,1997), (3,2,1998), (4,4,1999), (5,5,2000); 
INSERT INTO Buyers(BId, BName, BCity, Age) VALUES (1,'Pooja','Mysuru',22), (2,'Poonam','Bengaluru',54), 
(3,'Pallavi','Pune',29), (4,'anand','Mysuru',19), (5,'Ramesh','Bombay',22); 
 INSERT INTO Manufacturers(MName, Location) VALUES  ('Ford','Bengaluru'), ('Toyota','Mysuru'), 
('Tata','Dehli'), ('Maruti','Mysuru'), ('Honda','Bengaluru'); 
INSERT INTO Salespersons(SId, SName, YearsEmployeed) VALUES (1, 'Rob',10), (2, 'john',5), 
(3, 'ram',7), (4, 'mohan',2), (5, 'abhi',12); 
INSERT INTO Transactions(BId, CarId, SId, Amount, TMonth, TDay, TYear) values (1,1,1,9000,2,2,1997), (1,1,1,9000,2,2,1997), 
(2,2,2,10000,1,1,1997), (3,2,3,8000,1,3,1998), (4,5,5,5000,22,12,1997), (5,4,4,9000,6,22,2000); 
 

SELECT b.BName, b.BCity FROM Buyers b 

JOIN Transactions t ON t.BId = b.BId 

JOIN Cars c ON t.CarId = c.CarId 

JOIN Models mo ON mo.MId = c.MId 

JOIN Manufacturers m ON m.MName = mo.MName 

WHERE m.MName = 'Ford' AND mo.MModel = 'mustang' AND t.Amount < 10000; 



SELECT DISTINCT SId  
FROM transactions t 
JOIN Cars c ON t.CarId = c.CarId  
JOIN Models mo ON c.MId = mo.MId  
JOIN Manufacturers m ON mo.MName = m.MName  
WHERE (m.MName = 'Ford' OR m.MName = 'Toyota') AND t.TYear = 1997  
GROUP BY SId  
HAVING COUNT(DISTINCT m.MName) = 1; 


SELECT DISTINCT SId  
FROM transactions  
JOIN Cars ON transactions.CarId = Cars.CarId  
JOIN Models ON Cars.MId = Models.MId  
JOIN Manufacturers ON Models.MName = Manufacturers.MName; 

SELECT DISTINCT SName  
FROM Salespersons  
WHERE SId NOT IN (  
SELECT DISTINCT SId  
FROM Transactions  
WHERE TYear = 1997 ); 

SELECT DISTINCT SName  
FROM Salespersons  
WHERE SId NOT IN (  
SELECT DISTINCT SId  
FROM Transactions  
WHERE TYear = 1997 ); 

SELECT 
    S.SName,
    AVG(T.Amount) AS AverageAmountPerTransaction
FROM 
    Transactions T
JOIN 
    Salespersons S ON T.SId = S.SId
JOIN
    Cars C ON T.CarId = C.CarId
WHERE
    S.YearsEmployeed < 10
GROUP BY
    S.SName
HAVING
    COUNT(C.CarId) >= 50
ORDER BY
    AverageAmountPerTransaction DESC;




 

CREATE TABLE Employees( FName VARCHAR(255), MName VARCHAR(255), LName VARCHAR(255), SSN VARCHAR(255) PRIMARY KEY, 
BDate DATE, EAddress VARCHAR(255), Sex CHAR(1), Salary DECIMAL(10,2), SuperSsn VARCHAR(255), DNo INT ); 

INSERT INTO Employees(FName ,MName ,LName , SSN, BDate, EAddress, Sex, Salary, SuperSsn, DNo) VALUES 
('Bob','D','Smith','1234','2000-01-01','mysuru','M',20000,'2345',2), 
('Avengers','A','John','1235','2001-11-01','Bangaluru','M',25000,'2346',3), 
('Ram','K','K','1236','2001-01-05','Bombay','M',10000,'2347',5), 
('Mach','C','Pop','1237','2000-12-29','Pune','F',15700,'2348',3), 
('Rob','S','Sheild','1238','2002-08-11','Mysuru','F',32400,'2349',1), 
('Spider','M','Man','1239','2003-11-12','Bengaluru','M',20000,'2350',4); 

 

CREATE TABLE Departments(DName VARCHAR(255),DNumber INT PRIMARY KEY,MgrSsn VARCHAR(255),MgrStartDate DATE,
    FOREIGN KEY (MgrSsn) REFERENCES Employees(SSN)
);



INSERT INTO Departments(DName, DNumber, MgrSsn, MgrStartDate)  
VALUES ('Research',2,'1234','2000-01-01'), 
('Technology',1,'1235','2001-01-01'), 
('Chemistry',3,'1236','2002-04-11'), 
('Electrical',6,'1237','2000-01-01'), 
('Administartion',4,'1238','2000-01-01'), 
('Research',5,'1239','2000-01-01'); 



CREATE TABLE Dependents( 
ESsn VARCHAR(255) references Employees(Ssn), 
DependentName VARCHAR(255) PRIMARY KEY, 
Sex CHAR(2), 
BDate date, 
Relationship VARCHAR(255) 
); 


CREATE TABLE Dependents( ESsn VARCHAR(255) references Employees(Ssn), DependentName VARCHAR(255) PRIMARY KEY, 
Sex CHAR(2), BDate date, Relationship VARCHAR(255) ); 

INSERT INTO Dependents (ESsn, DependentName, Sex, BDate, Relationship) VALUES
('1234', 'John Doe', 'F', '1995-03-10', 'Son'),
('1235', 'Jane Doe', 'M', '1996-05-13', 'Daughter'),
('1236', 'Alice Smith', 'F', '2000-06-05', 'Spouse'),
('1237', 'Bob Smith', 'M', '2001-07-25', 'Spouse'),
('1238', 'Susan Johnson', 'M', '1990-09-03', 'Sibling'),
('1235', 'William Johnson', 'M', '1998-04-01', 'Brother'),  
('1234', 'David Brown', 'M', '2002-11-15', 'Sister'); 
 
CREATE TABLE DeptLocations(
    DNumber INT,
    DLocations VARCHAR(255) PRIMARY KEY,
    FOREIGN KEY (DNumber) REFERENCES Departments(DNumber)
);

INSERT INTO DeptLocations(DNumber, DLocations)  
VALUES (2,'Bengaluru'), (3,'Mysuru'), (4,'Pune'), (2,'Bombay'), 
(1,'Dehli'), (5,'Karwar'); 


CREATE TABLE Projects(
    PName VARCHAR(255),
    PNumber INT PRIMARY KEY,
    PLocation VARCHAR(255),
    DNum INT,
    FOREIGN KEY (DNum) REFERENCES Departments(DNumber)
);

INSERT INTO Projects(PName, PNumber, PLocation, DNum)  
VALUES  ('project 1', 1, 'Stafford', 5),  
('project 2', 2, 'Bengaluru', 4),  
('project 3', 3, 'Mysuru', 1),  
('project 4', 4, 'Karwar', 5), 
('project 5', 5, 'Dandeli', 5), 
('project 6', 6, 'Bengaluru', 5); 


CREATE TABLE WorksOn(
    ESsn VARCHAR(255),
    PNum INT,
    Hours DECIMAL(4,2),
    FOREIGN KEY (ESsn) REFERENCES Employees(SSN),
    FOREIGN KEY (PNum) REFERENCES Projects(PNumber)
);



INSERT INTO WorksOn(ESsn, PNum, Hours)  
VALUES ('1234',1,30), 
('1235',2,15), 
('1236',3,50), 
('1234',2,20), 
('1237',1,35), 
('1238',4,40), 
('1234',5,20), 
('1237',3,35), 
('1238',1,40); 

SELECT e.FName,e.EAddress FROM Employees e  
JOIN Departments d on e.DNo = D.DNumber  
where d.DName = 'Research'; 


SELECT  p.PNumber AS ProjectNumber, d.dnumber AS ControllingDepartmnetNumber, e.lname AS ManagerLastName,  
e.EAddress AS ManagerAddress,  
e.BDate AS ManagerBirthDate FROM Projects p  
JOIN Departments d on p.DNum = d.DNumber  
JOIN Employees e on d.MgrSsn = e.SSN  
WHERE p.PLocation = 'Stafford';  


SELECT e.FName FROM Employees e 
JOIN WorksOn  w ON w.ESsn = e.SSN 
JOIN Projects p ON p.PNumber = w.PNum 
WHERE p.DNum = 5 
GROUP BY e.SSN, e.FName, e.LName; 
 
 
SELECT DISTINCT p.PNumber  
FROM Projects p  
JOIN WorksOn w ON p.PNumber = w.PNum  
JOIN Employees e ON w.ESsn = e.SSN  
WHERE e.LName = 'Smith'  
UNION  
SELECT DISTINCT p.PNumber  
FROM Projects p  
JOIN Departments d ON p.DNum = d.DNumber  
JOIN Employees e ON d.MgrSsn = e.SSN  
WHERE e.LName = 'Smith'; 



SELECT DISTINCT e.FName FROM Employees e  
JOIN Dependents d ON d.ESsn = e.SSN 
WHERE (SELECT COUNT(*) FROM Dependents d WHERE d.ESsn=e.SSN ) >=2;


SELECT e.FName, e.LName  
FROM Employees e  
WHERE NOT EXISTS (SELECT 1  
FROM Dependents d  
WHERE d.ESsn = e.SSN ); 
 
 
SELECT DISTINCT e.FName, e.LName  
FROM Employees e  
WHERE e.SSN IN (  
SELECT DISTINCT d.MgrSsn  
FROM Departments d ) 
AND e.SSN IN (  
SELECT DISTINCT ESsn  
FROM Dependents  ); 








 